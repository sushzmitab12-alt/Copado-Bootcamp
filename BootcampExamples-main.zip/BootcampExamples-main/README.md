# BootcampExamples

The intent of this Repository is to hold several file examples (Metadata format) referenced throughout the Copado Bootcamp Sessions
